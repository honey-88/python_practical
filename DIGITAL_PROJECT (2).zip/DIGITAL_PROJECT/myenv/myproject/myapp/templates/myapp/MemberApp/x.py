a = "karan"
b = "kapadiya"
c = a+b
zip(c)
c