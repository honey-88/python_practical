"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/',views.login,name="login"),
    path('logout/',views.logout,name="logout"),
    path('register-member/',views.register_member,name="register-member"),
    path('all-members/',views.all_members,name="all-members"),
    path('add-notice/',views.add_notice,name="add-notice"),
    path('notice-list/',views.notice_list,name="notice-list"),
    path('add-event/',views.add_event,name="add-event"),
    path('all-event/',views.all_event,name="all-event"),
    path('specific-user/<int:pk>/',views.specific_user,name="specific-user"),
    path('myprofile/',views.myprofile,name="myprofile"),
    path('delete-user/<int:pk>/',views.delete_user,name="delete-user"),
    path('m_login/',views.login,name="m_login"),
    path('m_all_members/',views.all_members,name="m_all_members"),
    path('m_profile/',views.myprofile,name="m_profile"),
    path('m_noticelist/',views.notice_list,name="m_noticelist"),
    path('m_allevent/',views.all_event,name="m_allevent"),
    path('m_specificprofile/<int:pk>/',views.specific_user,name="m_specificprofile"),
    path('m_delete-user/<int:pk>/',views.delete_user,name="m_delete-user"),

]
