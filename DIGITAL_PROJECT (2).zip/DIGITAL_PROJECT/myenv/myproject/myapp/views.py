import email
from importlib.resources import contents
from random import *
from urllib.request import Request
from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import redirect 
from django.urls import reverse
from .models import *

# Create your views here.
def home(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role=="Chairman":
            cid = Chairman.objects.get(user_id=uid)
            print("----uid",uid)
            print("---password----",uid.password)
            print ("----->login successfully----")
            
            print("====>firstname  ",cid.firstname)
            print("====>lastname   ",cid.lastname)
        
            context = {
                'uid' : uid,
                'cid' : cid,
            }
            return render(request,"myapp/c_index.html",context)
        else:
            uid = User.objects.get(email = request.session['email'])
            if uid.role=="Member":
                mid = Member.objects.get(user_id=uid)
                print("----uid",uid)
                print("---password----",uid.password)
                print ("----->login successfully----")
            
                print("====>firstname  ",mid.firstname)
                print("====>lastname   ",mid.lastname)
        
                context = {
                    'uid' : uid,
                    'mid' : mid,
                 }
                print("---> member loggged ")
                print("--------------------------")
                return render(request,"myapp/MemberApp/m_index.html")

def second(request):
    return render(request,"myapp/second.html")

def login(request):
    if 'email' in request.session:
        return HttpResponseRedirect(reverse('home'))
    else:
        if request.POST:
            print("----button clickeddd")
            email=request.POST['email']
            password = request.POST['password']

            print("---------------email---",email)
            
            try:
                uid = User.objects.get(email = email)
                if uid.role=="Chairman":
                    print("----uid",uid)
                    print("---password----",uid.password)
                    if password==uid.password:
                        print ("----->login successfully----")
                        cid = Chairman.objects.get(user_id=uid)
                        print("====>firstname  ",cid.firstname)
                        print("====>lastname   ",cid.lastname)
                        request.session['email'] = uid.email    #browser - memory - session 
                        context = {
                            'uid' : uid,
                            'cid' : cid
                        }
                        return render(request,"myapp/c_index.html",context)
                    else:
                        print("invalid password")
                        return render(request,"myapp/login.html")
                else:
                    if uid.role=="Member":
                        print("----uid",uid)
                        print("---password----",uid.password)
                        if password==uid.password:
                        
                            print ("----->login successfully----")
                            mid = Member.objects.get(user_id=uid)
                            print("====>firstname  ",mid.firstname)
                            print("====>lastname   ",mid.lastname)
                            request.session['email'] = uid.email    #browser - memory - session 
                            context = {
                                    'uid' : uid,
                                    'mid' : mid,
                                }
                            return render(request,"myapp/MemberApp/m_index.html",context)
                        else:
                            print("invalid password")
                            return render(request,"myapp/login.html")
            except:
                print("invalid password")
                context = {
                        'e_msg' : 'invalid email and password'
                    }
                return render(request,"myapp/login.html",context)
        return render(request,"myapp/login.html")
                    

def logout(request):
    if "email" in request.session:
        del request.session['email'] 
        return render(request,"myapp/login.html")
    else: 
        return HttpResponseRedirect(reverse('login'))
    

def register_member(request): 
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role == 'Chairman':
                 #return render(request,"myapp/add-member.html")
            cid = Chairman.objects.get(user_id = uid)
            context = {
                        'uid' : uid,
                        'cid' : cid,
            }     
            if request.POST:
                print("--------insert data")
                email = request.POST['email']
                mydata = ["98hbdcs","879ncHHJU","29nYCR","89nED","89sd3nC"]
                passcode = request.POST['firstname'][-3:-1] + email[3:6] + choice(mydata) 
                print("------>passcode",passcode)
                #in django which is user ORM (object relational mapping)
                # here, we are using create() insted of insert()
                #for data register or enter or store or add data use create()
                user_id = User.objects.create(email = email,password = passcode,role = "member")
                mid = Member.objects.create(user_id = user_id,
                                            firstname = request.POST['firstname'],
                                            lastname = request.POST['lastname'],
                                            contact = request.POST['contact'],
                                            gender = request.POST['gender'],
                                            house_no = request.POST['house_no'],
                                            occupation = request.POST['occupation'],
                                            working_place = request.POST['working_place'],
                                            family_member  = request.POST['family_member'],
                                            vehical_details = request.POST['vehical_details'],
                                            blood_group = request.POST['blood_group'],
                                            birthdate = request.POST['birthdate'])

                all_member=Member.objects.all()
                all_member = {
                'all_members' : all_member
                }
                return render(request,"myapp/add-member.html",context)
            else:
                print("only redirect to page")
                return render(request,"myapp/add-member.html",context)

def all_members(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        print("----> ",uid.role)
        print("----> role",uid.role)
        if uid.role == 'Chairman':

            cid = Chairman.objects.get(user_id = uid)
            print("------> role",cid.firstname)
            all_member = Member.objects.all()
            context = {
                      'all_members' : all_member
            }   
            return render(request,"myapp/all_members.html",context)
        else:
            mid = Member.objects.get(user_id = uid)
            print("------> role",mid.firstname)
            m_all_member = Member.objects.all()
            context = {
                      'm_all_members' : m_all_member
            }   
            return render(request,"myapp/MemberApp/m_all_members.html",context)
    else:
        return render(request,"myapp/all_members.html")



def add_notice(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        print("----> ",uid.role)
        print("----> role",uid.role)
        if uid.role == 'chairman':

            cid = Chairman.objects.get(user_id = uid)
            print("------> role",cid.firstname)
                
            if request.POST:
                title = request.POST['title']
                description = request.POST['description']
                if "pic" in request.FILES:
                    pic = request.FILES['pic']
                    nid = Notice.objects.create(user_id = uid,title = title,description = description, pic = pic)
                else:
                    nid = Notice.objects.create(user_id = uid,title = title,description = description)
                if nid:
                    s_msg = "successfully notice uploaded"
                    context = {
                        'uid' : uid,
                        'cid' : cid,
                        's_msg' : s_msg,
                    }
                    return render(request,"myapp/add-notice.html",context)
            else:
                return render(request,"myapp/add-notice.html")
    return render(request,"myapp/add-notice.html")

def notice_list(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        print("----> ",uid.role)
        print("----> role",uid.role)
        if uid.role == 'Chairman':
            cid = Chairman.objects.get(user_id = uid)
            nall = Notice.objects.all()
            context = {
                'uid' : uid,
                'cid' : cid,
                'nall' : nall,
            }
            return render(request,"myapp/notice-list.html",context)
        else:
            mid = Member.objects.get(user_id = uid)
            m_nall = Notice.objects.all()
            context = {
                'uid' : uid,
                'mid' : mid,
                'm_nall' : m_nall,
            }
            return render(request,"myapp/MemberApp/m_noticelist.html",context)
    else:
        return render(request,"myapp/notice-list.html")



def add_event(request):
    if "email" in request.session:  #this line for check someone already logged in or not
        uid = User.objects.get(email = request.session['email'])  #check who one logged in
        if uid.role == "Chairman":  #to check is logged in person is chairman or not 
            cid = Chairman.objects.get(user_id = uid) #fetch data from chairman table
            
            if request.POST:
                title = request.POST['title']

                print("-----> title",title)
                if "pic" not in request.FILES and "video" not in request.FILES:
                    eid = Event.objects.create(user_id = uid,title = title,description = request.POST['description'],
                                        date_event = request.POST['date_event'],event_time = request.POST['event_time'])
                elif "pic" in request.FILES and "video" not in request.FILES:
                     eid = Event.objects.create(user_id = uid,title = title,description = request.POST['description'],
                                        date_event = request.POST['date_event'],event_time = request.POST['event_time'],pic = request.FILES['pic'])
                elif "video" in request.FILES and "pic" not in request.FILES:
                     eid = Event.objects.create(user_id = uid,title = title,description = request.POST['description'],
                                        date_event = request.POST['date_event'],event_time = request.POST['event_time'],video = request.FILES['video'])  
                else:
                    eid = Event.objects.create(user_id = uid,title = title,description = request.POST['description'],
                                        date_event = request.POST['date_event'],event_time = request.POST['event_time'],pic = request.FILES['pic'],video = request.FILES['video'])  
                                          
                context = {
                    'uid' : uid,
                    'cid' : cid,
                }
                return render(request,"myapp/add-event.html",context)
                
            else:
                context = {
                    'uid' : uid,
                    'cid' : cid,
                }
                return render(request,"myapp/add-event.html",context)
        else:   #login person socitey member
            pass
    else:   #on ones logged before this operations
        return render(request,"myapp/login.html")

def all_event(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        print("----> ",uid.role)
        print("----> role",uid.role)
        if uid.role == 'Chairman':
            cid = Chairman.objects.get(user_id = uid)
            eall = Event.objects.all()
            context = {
                'uid' : uid,
                'cid' : cid,
                'eall' : eall,
            }
            return render(request,"myapp/all-event.html",context)
        else:
            mid = Member.objects.get(user_id = uid)
            m_eall = Event.objects.all()
            context = {
                'uid' : uid,
                'mid' : mid,
                'm_eall' : m_eall,
            }
            return render(request,"myapp/MemberApp/m_allevent.html",context)
    else:
           return render(request,"myapp/all-event.html")


def specific_user(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role == 'Chairman':
            cid = Chairman.objects.get(user_id = uid)
            specific_uid = Member.objects.get(id = pk)
            context = {
                    'uid' : uid,
                    'cid' : cid,
                'specific_uid' : specific_uid,
                }
            return render(request,"myapp/specific_profile.html",context)
        else:
            mid = Member.objects.get(user_id = uid)
            m_specific_uid = Member.objects.get(id = pk)
            context = {
                    'uid' : uid,
                    'mid' : mid,
                'm_specific_uid' : m_specific_uid,
                }
            return render(request,"myapp/MemberApp/m_specificprofile.html",context)
    else:
         return render(request,"myapp/specific_profile.html")

       


def myprofile(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role == 'Chairman':
                cid = Chairman.objects.get(user_id = uid)
                if request.POST:
                    cid.firstname = request.POST['firstname']
                    cid.lastname = request.POST['lastname']
                    if"pic" in request.FILES:
                        cid.pic = request.FILES['pic']
                    cid.save()
                context = {
                    'uid' : uid,
                    'cid' : cid,
                }
                return render(request,"myapp/profile.html",context)
        else:
            mid = Member.objects.get(user_id = uid)
            if request.POST:
                mid.firstname = request.POST['firstname']
                mid.lastname = request.POST['lastname']
                if "pic" in request.FILES:
                    mid.pic = request.FILES['pic']
                    mid.save()
                    context = {
                        'uid' : uid,
                        'mid' : mid,
                    }
                    return render(request,"myapp/MemberApp/m_profile.html",context)
            else:
                return render(request,"myapp/profile.html")


def delete_user(request,pk):
     if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role == 'Chairman':
            cid = Chairman.objects.get(user_id = uid)
            
            duser = Member.objects.get(id = pk)
            duser.delete()
            return redirect('all-members')
        


 
