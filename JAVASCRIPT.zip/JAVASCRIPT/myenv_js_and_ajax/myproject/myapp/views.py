from django.shortcuts import render
from.models import *


# Create your views here.

def home(request):
    return render(request,"myapp/index.html")

def index(request):
    return render(request,"myapp/ajax_index.html")

def insert(request):
    if request.POST:
        print("----> python side ", request.POST['fname'])
        return render(request,"myapp/ajax_index.html")