import scrapy


class MysiteSpider(scrapy.Spider):
    name = 'mysite'
    allowed_domains = ['mysite.com']
    start_urls = ['http://mysite.com/']

    def parse(self, response):
        pass
